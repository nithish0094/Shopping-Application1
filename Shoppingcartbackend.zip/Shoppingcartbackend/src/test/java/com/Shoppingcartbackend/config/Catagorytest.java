package com.Shoppingcartbackend.config;

import org.junit.experimental.categories.Category;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;



public class Catagorytest {

public static void main(String[] args)	{
	
	
	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
	
	context.scan("com.Shoppingcart");
	
	context.refresh();
	Category catagoryDAO = (Category) context.getBean("catagoryDAO");

	Category catagory = (Catagory) context.getBean("catagory");
	
	
	catagory.setid("MOB01");
	catagory.setname("IPhone7");
	catagory.setDescreption("IPhone is an Iphone");
	
	catagoryDAO.saveOrUpdate(catagory);
	
	System.out.println("Data inserted into DB");

}
	
	
		
}
