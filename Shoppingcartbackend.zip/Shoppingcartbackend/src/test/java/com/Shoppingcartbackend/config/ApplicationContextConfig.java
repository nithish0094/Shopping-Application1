package com.Shoppingcartbackend.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.Shoppingcart.model.Catagory;

@Configuration
@ComponentScan("com.Shoppingcart")
@EnableTransactionManagement


public class ApplicationContextConfig {

	@Bean(name="dataSource")
	public DataSource getH2DataSource(){
		DriverManagerDataSource dataSource = new  DriverManagerDataSource();
			String url = "jdbc:h2:Shoppingcart;" +
		"INIT=CREATE SCHEMA IF NOT EXIST SHOPPINGCART";
		dataSource.setDriverClassName("org.h2.Driver");
		dataSource.setUrl(url);
		
		dataSource.setUsername("sa");
		dataSource.setPassword("");
		return dataSource;	
	}
	
	
	
	
	private Properties getHibenateProperties(){
		Properties properties = new Properties() ;
		properties.put("hibernate.show_sql","true");
		properties .put("hibernate.dialect","org.hibernate.dialect.H2Dialect");
		return properties;
	}
	
	@Autowired
	@Bean(name= "seasonFactory")
	public SessionFactory getsessionFactory(DataSource dataSource){
		LocalSessionFactoryBean sessionBuilder = new LocalSessionFactoryBulider(dataSource);
		sessionBuilder.addProperties(getHibernateProperties());
		sessionBuilder.addAnnotationClasses(Catagory.class);
		sessionBuilder.addAnnotationClasses(Supplier.class);
		sessionBuilder.addAnnotationClasses(Cart.class);
		sessionBuilder.addAnnotationClasses(User.class);
		sessionBuilder.addAnnotationClasses(Product.class);
		sessionBuilder.addAnnotationClasses(Account.class);
		return sessionBuilder.buildSessionFactory();
	}
	
	@Autowired
	@Bean(name = "tansactionManager")
	public HibernateTransactionManager getTransactionManager(SessionFactory sessionFactory){
		
		HibernateTransactionManager transactionManager = new HibernateTransactionManager(sessionFactory);
		
		return transactionManager;
		
		
		
		
	}
	
	
	
}
