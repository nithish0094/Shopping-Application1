package com.Shoppingcartbackend.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate3.LocalSessionFactoryBean;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.Shoppingcart.model.Account;
import com.Shoppingcart.model.Cart;
import com.Shoppingcart.model.Catagory;
import com.Shoppingcart.model.Product;
import com.Shoppingcart.model.Supplier;
import com.Shoppingcart.model.User;

@Configuration
@ComponentScan("com.Shoppingcart")
@EnableTransactionManagement


public class ApplicationContextConfig {

	@Bean(name="dataSource")
	public DataSource getH2DataSource(){
		DriverManagerDataSource dataSource = new  DriverManagerDataSource();
	/*		String url = "jdbc:h2:Shoppingcart;" +
		"INIT=CREATE SCHEMA IF NOT EXIST SHOPPINGCART";
		*/
		dataSource.setUrl("jdbc:h2:mem:tmp.db;INTI=CREATE SCHEMA IF NOT  EXISTS SHOPPINGCART");
		dataSource.setDriverClassName("org.h2.Driver");
		
		
		dataSource.setUsername("sa");
		dataSource.setPassword("");
		return dataSource;	
	}
	
	
	
	
	private Properties getHibenateProperties(){
		Properties properties = new Properties() ;
		properties.put("hibernate.show_sql","true");
		properties .put("hibernate.dialect","org.hibernate.dialect.H2Dialect");
		return properties;
	}
	
	@Autowired
	@Bean(name= "seasonFactory")
	public SessionFactory getSessionFactory(DataSource dataSource){
		LocalSessionFactoryBuilder sessionBuilder = new LocalSessionFactoryBuilder(dataSource);
		sessionBuilder.addProperties(getHibenateProperties());
		sessionBuilder.addAnnotatedClasses(Catagory.class);
		sessionBuilder.addAnnotatedClasses(Supplier.class);
		sessionBuilder.addAnnotatedClasses(Cart.class);
		sessionBuilder.addAnnotatedClasses(User.class);
		sessionBuilder.addAnnotatedClasses(Product.class);
		sessionBuilder.addAnnotatedClasses(Account.class);
		return sessionBuilder.buildSessionFactory();
	}
	
	@Autowired
	@Bean(name = "tansactionManager")
	public HibernateTransactionManager getTransactionManager(SessionFactory sessionFactory){
		
		HibernateTransactionManager transactionManager = new HibernateTransactionManager(sessionFactory);
		
		return transactionManager;
		
		
		
		
	}
	
	
	
}
