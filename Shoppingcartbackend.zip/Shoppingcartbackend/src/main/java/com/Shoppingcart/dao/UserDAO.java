package com.Shoppingcart.dao;

import java.util.List;

import com.Shoppingcart.model.User;
import com.Shoppingcart.model.UserDetails;

public interface UserDAO {
	
public List<User> list();
public UserDetails get(String id);

public void saveOrupdate(UserDetails userDetails);

public void delete(String id);

public boolean isValid(String id, String Password);

}
