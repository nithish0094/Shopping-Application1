package com.Shoppingcart.dao;

public class UserDetailsDAOImpl {

}
