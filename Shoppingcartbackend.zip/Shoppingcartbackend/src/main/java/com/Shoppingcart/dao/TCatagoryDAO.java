package com.Shoppingcart.dao;

import java.util.List;

import com.Shoppingcart.model.TCatagory;

public interface TCatagoryDAO {

	public boolean save(TCatagory catagory);
	public boolean update(TCatagory catagory);
	public boolean delete(String id);
	
	public TCatagory get(String id);
	
	public List<TCatagory> list();
		
	
		
}
