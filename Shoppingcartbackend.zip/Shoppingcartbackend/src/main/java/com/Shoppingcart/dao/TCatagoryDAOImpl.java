package com.Shoppingcart.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository("tcatagoryDAO")
public class TCatagoryDAOImpl implements TCatagoryDAO {
	
	public boolean save(TCatagory catagory){
		return false;
	}
	
	public boolean update(TCatagory catagory){
		return false;
		
	}
	public boolean delete(String id){
		return false;	
	}
	
	public TCatagory get(String id){
		return null;
	}
	
	public List<TCatagory> list(){

		return null;
	
	}
	@Autowired
	private SessionFactory sessionFactory;
	
	public TCatagoryDAOImpl(SessionFactory sessionFactory){
		this.sessionFactory = sessionFactory;
	}
	
	public boolean save(TCatagory catagory){
		try
		{
			sessionFactory.getCurrentSession().save(catagory);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
		return true;		
	}


		public boolean update(TCatagory catagory){
			try
			{
				sessionFactory.getCurrentSession().update(catagory);
			}catch(Exception e)
			{
				e.printStackTrace();
				return false;
			}
			return true;		
}

	
		public boolean delete(Sring id){
			try
			{
				sessionFactory.getCurrentSession().delete(get(id));
			}
			catch(Exception e)
			{
				e.printStackTrace();
				return false;
			}
			return true;		
		}
		public TCatagory get(String id)
		{
			
			String hql = "from TCatagory where id =" + id + "'";
			Query query = sessionFactor.getCurrentSession().createQuery(hql);
		
			
			List<TCatagory> list = query.list();
			if(list !=null && list.isEmpty()	)
			return null;
	
			
		}
		public List<TCatagory> list()
		{
			return null;
		}
}