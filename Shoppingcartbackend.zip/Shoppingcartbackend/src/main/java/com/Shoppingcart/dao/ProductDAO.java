package com.Shoppingcart.dao;

public interface ProductDAO {

}
