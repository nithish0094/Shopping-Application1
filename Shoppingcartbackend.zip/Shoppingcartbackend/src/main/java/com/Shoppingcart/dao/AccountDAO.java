package com.Shoppingcart.dao;

public interface AccountDAO {

}
