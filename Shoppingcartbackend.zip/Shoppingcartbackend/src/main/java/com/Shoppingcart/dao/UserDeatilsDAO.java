package com.Shoppingcart.dao;

public interface UserDeatilsDAO {

}
