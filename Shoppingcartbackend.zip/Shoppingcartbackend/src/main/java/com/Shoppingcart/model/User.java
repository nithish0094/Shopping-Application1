package com.Shoppingcart.model;

public class User {

}
