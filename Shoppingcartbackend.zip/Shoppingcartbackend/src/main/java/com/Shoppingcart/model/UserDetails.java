package com.Shoppingcart.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "USER_DETAILS")
@Component

public class UserDetails {

	
	@Id
	private String id;
	private String password;
	private String name;
	private String email;
	private String address;
	private String mobile;
	private String role;
	
}
