package com.Shoppingcart.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.junit.experimental.categories.Category;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "CATAGORY")
@Component

	public class Catagory{

	private String id;
	private String name;
	private String descreption;
	private Set<Product> products;
	
	@OneToMany(mappedBy="catagory",fetch = FetchType.EAGER)
	public	Set<Product> getProduct(){
			return products;
	}
	@Id
	@Column(name = "ID")
	public String getId(){
		return id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescreption() {
		return descreption;
	}
	public void setDescreption(String descreption) {
		this.descreption = descreption;
	}
	
	
	public Set<Product> getProducts() {
		return products;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setProducts(Set<Product> products){
		this.products = products;
	}


	
}
