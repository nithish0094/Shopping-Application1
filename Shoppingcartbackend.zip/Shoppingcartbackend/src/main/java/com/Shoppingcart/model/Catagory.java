package com.Shoppingcart.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.Table;
import org.springframework.stereotype.Component;

@Entity
@Table(nmae = "CATEGOY")
@Component

	public class Catagory {

	private String id;
	private String name;
	private String descreption;
	private Set<Product> products;
	
	@OneToMany(mapped="catagory",featch = FetchType.EAGER)
	pulbic	Set<Product> getProduct(){
			return products;
	}
	@Id
	@Column(name = "ID")
	public String getId(){
		return id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescreption() {
		return descreption;
	}
	public void setDescreption(String descreption) {
		this.descreption = descreption;
	}
	public pulbic getSet() {
		return Set;
	}
	public void setSet(pulbic set) {
		Set = set;
	}
	public Set<Product> getProducts() {
		return products;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setProducts(Set<Product> products){
		this.products = products;
	}


	
}
