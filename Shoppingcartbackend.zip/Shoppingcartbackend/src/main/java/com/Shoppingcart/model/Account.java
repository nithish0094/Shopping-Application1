package com.Shoppingcart.model;

public class Account {

}
