package com.Shoppingcart.model;

public class Suppliar {

}
