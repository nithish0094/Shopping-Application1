package com.Shoppingcart.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.springframework.stereotype.Component;


@SuppressWarnings("unused")
@Entity
@Table(name = "CATAGORY")
@Component

	public class Catagory{

	private String id;
	private String name;
	private String descreption;

	
/*	@OneToMany(mappedBy="catagory",fetch = FetchType.EAGER)*/

	

/*	
	@OneToMany(mappedBy="catagory")
	private Set<Product> products;*/
	
	
	@Id
	@Column(name="ID")
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescreption() {
		return descreption;
	}
	public void setDescreption(String descreption) {
		this.descreption = descreption;
	}
	
	public void setid(String id) {
		this.id = id;
	}
	


	
}
