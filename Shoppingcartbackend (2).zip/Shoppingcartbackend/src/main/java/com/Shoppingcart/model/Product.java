package com.Shoppingcart.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "PRODUCT")
@Component

public class Product {

	@Id
	private String id;
	private String name;
	private String descreption;
	/*private Set<Product> getProduct;*/
	/*private String catagory_id;
	private String supplier_id;*/
/*	
	@ManyToOne
	@JoinColumn(name = "catagory_id",updatable = false, insertable = false)
	private Catagory catagory;
	
	@ManyToOne
	@JoinColumn(name = "supplier_id",nullable = false,updatable = false,insertable = false)
	private Supplier supplier; */
	
/*	public Catagory getCatagory() {
		return catagory;
	}
	public void setCatagory(Catagory catagory) {
		this.catagory = catagory;
	}
	public Supplier getSupplier() {
		return supplier;
	}
	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}*/
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescreption() {
		return descreption;
	}
	public void setDescreption(String descreption) {
		this.descreption = descreption;
	}
	

}
