package com.Shoppingcart.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.Shoppingcart.model.Catagory;

@Repository("catagoryDAO")
public interface CatagoryDAO {

	public boolean save(Catagory catagory);
	
	public boolean  update(Catagory catagory);
	
	public boolean  delete(String id);
	
	public Catagory get(String id);
	
	public List<Catagory> list();
}