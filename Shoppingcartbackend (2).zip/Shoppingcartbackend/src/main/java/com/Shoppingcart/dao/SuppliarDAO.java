package com.Shoppingcart.dao;

public interface SuppliarDAO {

}
