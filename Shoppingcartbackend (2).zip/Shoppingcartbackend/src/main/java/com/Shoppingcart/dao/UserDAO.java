package com.Shoppingcart.dao;

import java.util.List;

import org.h2.engine.User;

import com.Shoppingcart.model.UserDetails;

public interface UserDAO {
	
public List<User> list();
public UserDetails get(String id);

public void save(UserDetails userDetails);

public void update(UserDetails userDetails);

public void delete(String id);

public boolean isValid(String id, String Password);

}
