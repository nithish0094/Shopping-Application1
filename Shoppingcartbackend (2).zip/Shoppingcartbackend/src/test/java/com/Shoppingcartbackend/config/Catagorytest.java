package com.Shoppingcartbackend.config;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.Shoppingcart.dao.CatagoryDAO;
import com.Shoppingcart.model.Catagory;



public class Catagorytest {

public static void main(String[] args) {
	
	
	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
	context.scan("com.Shoppingcart");
	context.refresh();
	
	CatagoryDAO catagoryDAO = (CatagoryDAO) context.getBean("catagoryDAO");
	Catagory catagory = (Catagory) context.getBean("catagory");
	

	
	
	 catagory.setId("MOB001");
	 catagory.setName("IPhone7");
	 catagory.setDescreption("IPhone is an Iphone");
	
	
	catagoryDAO.save(catagory);
	System.out.println("Data inserted into DB");

}
	
	
		
}
