package com.Shoppingcartbackend.config;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.Shoppingcart.dao.CatagoryDAO;
import com.Shoppingcart.model.Catagory;





public class CatagoryTestCase {

	
	@Autowired
	AnnotationConfigApplicationContext context;

	@Autowired
	private CatagoryDAO catagoryDAO;
	
	@Autowired
	Catagory catagory;
	
	@Before
	public void init()
	{
	context = new 	AnnotationConfigApplicationContext();
	context.scan("com.Shoppingcart");
	context.refresh();
	
	
	catagory = (Catagory) context.getBean("catagory");
	catagoryDAO = (CatagoryDAO) context.getBean("catagoryDAO");
	
}
	
	@Test
	public void createCatagoryTestCase(){
	
		catagory.setId("MOB002");
		catagory.setName("Mi 5S");
		catagory.setDescreption("Awesome");
		catagoryDAO.save(catagory);
	
		Assert.assertEquals("Save Catagory", true , catagoryDAO.save(catagory));
		
		
	
	}
	@Test
	public void updateCatagoryTestCase(){
		
		catagory.setId("MOB001");
		catagory.setName("iPhone7 Pluse");
		catagory.setDescreption("An  iPhone is an iPhone");
		
		Assert.assertEquals("Update Catagory",true,catagoryDAO.update(catagory));
	}
	@Test
	public void deleteCatagoryTestCase()
	{
		
		
	catagoryDAO.delete("MOB02");
	Assert.assertEquals("Delete Catagory", true, catagoryDAO.delete("MOB02") );
	}
	@Test
	public void getCatagoryTestCase()
	{
		Assert.assertEquals("Get Catagory", true,catagoryDAO.get("Mob001"));
	}
	@Test
	public void listCatagoryTestCase()
	{
		Assert.assertEquals("List Catagory",	5 ,catagoryDAO.list().size());
	}
}