package com.Shoppingcartbackend.config;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.Shoppingcart.dao.ProductDAO;
import com.Shoppingcart.model.Product;

public class Producttest {
	
	public static void main(String[] args){
		
		
		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.Shoppingcart");
		
		context.refresh();
		
		@SuppressWarnings("unused")
		ProductDAO productDAO = (ProductDAO) context .getBean("productDAO");
		
		Product product = (Product)context.getBean("product");
		
		
		product.setId("MOB001");
		product.setName("iPhone 7Plus");
		product.setDescreption("Exception but awesome");
		
		System.out.println("Product Inserted in DB");
		

	}

}
