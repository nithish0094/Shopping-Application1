package com.Shoppingcartbackend.config;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.Shoppingcart.dao.ProductDAO;
import com.Shoppingcart.model.Product;

public class ProductTestCase {

	@Autowired
	AnnotationConfigApplicationContext context;

	@SuppressWarnings("unused")
	@Autowired
	private ProductDAO productDAO;
	
	@Autowired
	Product product;
	
	@Before
	public void init()
	{
		context = new AnnotationConfigApplicationContext();
		context.scan("com.Shoppingcart");
		context.refresh();
		
		product = (Product) context.getBean("product");
		productDAO = (ProductDAO)context.getBean("productDAO");
	}
	
	/*@Test
	public void createProductTestCase
	{
	product.getId()	;

	Assert.assertEquals
	}*/
	}


