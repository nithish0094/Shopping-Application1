package com.Shoppingcartbackend.config;

import static org.junit.Assert.*;

import org.junit.Test;

public class UserTestCase {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
