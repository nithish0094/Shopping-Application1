package Model;

public class Login 
{
	String Uname,Passwd;

	public String getUname() {
		return Uname;
	}

	public void setUname(String uname) {
		Uname = uname;
	}

	public String getPasswd() {
		return Passwd;
	}

	public void setPasswd(String passwd) {
		Passwd = passwd;
	}
	public boolean isValidLogin()
	{
		if(Uname.equals("NIIT")&& Passwd.equals("12345")) 
			return true;
		else
			return false;
	
	}

}
