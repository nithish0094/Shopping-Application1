/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.domain;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author MRuser
 */
public class Employee {
    int empID;
    String empName;
    String empssn;
    double empsalary;
   
    public void setempID(int empID){
        this.empID = empID;
    }
    

    public int getempID() { 
     
        return empID;
    }

    public void setempName(String empName) {
        this.empName = empName;
    }
    public String getempName(){
        return empName;
    }
    public void setempssn(String empssn){
        this.empssn = empssn;
    }

    public String getempssn() {
        return empssn;
    }
    public void setempsalary(double empsalary){
        this.empsalary = empsalary;
    }

    public double getempsalary() {
        return empsalary;
    }

  
        

}
