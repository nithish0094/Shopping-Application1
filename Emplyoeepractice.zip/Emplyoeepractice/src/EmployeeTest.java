/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import com.example.domain.Employee;

/**
 *
 * @author MRuser
 */
public class EmployeeTest {

    
    
        
        
public static void main (String[] args){
 Employee emp = new Employee();

emp.setempID(101);
emp.setempName("John Smith");
emp.setempssn("011-22-3467");
emp.setempsalary (120345.27);
int a=emp.getempID();
String b=emp.getempName();
String c=emp.getempssn();
double d=emp.getempsalary();
System.out.println("EmployeeID is"+a);
System.out.println("Employee Name is"+b);
System.out.println("Employee social security number"+c);
System.out.println("Employee salaey is"+d);

        }
}
